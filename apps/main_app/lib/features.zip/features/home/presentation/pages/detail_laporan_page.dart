import 'package:flutter/material.dart';
import 'package:core_module/core_module.dart';

// ========================
// MODEL (sama seperti di home_page.dart)
// ========================
class LaporanItem {
  final String nama;
  final String lokasi;
  final String status;
  final Color statusColor;
  final String? badge;
  final String imageUrl;
  final String? imbalan;
  final String kategori;
  final String waktuLapor;
  final String deskripsi;

  const LaporanItem({
    required this.nama,
    required this.lokasi,
    required this.status,
    required this.statusColor,
    this.badge,
    required this.imageUrl,
    this.imbalan,
    required this.kategori,
    required this.waktuLapor,
    required this.deskripsi,
  });
}

// ========================
// HALAMAN DETAIL LAPORAN
// ========================
class DetailLaporanPage extends StatelessWidget {
  final LaporanItem item;

  const DetailLaporanPage({super.key, required this.item});

  bool get isKehilangan => item.imbalan != null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // ---- KONTEN SCROLLABLE ----
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Foto + Overlay Info
                _buildHeroImage(context),

                const SizedBox(height: 20),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Banner Imbalan (hanya jika barang hilang)
                      if (isKehilangan) _buildImbalanBanner(),
                      if (isKehilangan) const SizedBox(height: 20),

                      // Deskripsi Lengkap
                      _buildDeskripsi(),
                      const SizedBox(height: 16),

                      // Kategori + Waktu Lapor
                      _buildInfoChips(),
                      const SizedBox(height: 24),

                      // Tombol Ajukan Klaim
                      _buildKlaimButton(context),

                      // Ruang untuk bottom nav
                      const SizedBox(height: 120),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ---- TOMBOL BACK & BOOKMARK (overlay di atas foto) ----
          _buildTopButtons(context),
        ],
      ),

      // ---- FAB ----
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton(
            backgroundColor: AppColors.primaryYellow,
            shape: const CircleBorder(
              side: BorderSide(color: AppColors.primaryBlue, width: 4),
            ),
            onPressed: () {},
            child: const Icon(Icons.add,
                color: AppColors.primaryBlue, size: 35),
          ),
          const SizedBox(height: 4),
          const Text(
            'Lapor',
            style: TextStyle(
              color: AppColors.primaryBlue,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,

      // ---- BOTTOM NAV ----
      bottomNavigationBar: BottomAppBar(
        padding: EdgeInsets.zero,
        notchMargin: 8,
        shape: const CircularNotchedRectangle(),
        child: CustomBottomNav(
          currentIndex: 0,
          onTap: (index) {},
        ),
      ),
    );
  }

  // ========================
  // WIDGET: HERO IMAGE + OVERLAY
  // ========================
  Widget _buildHeroImage(BuildContext context) {
    return SizedBox(
      height: 320,
      width: double.infinity,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Foto
          Image.network(
            item.imageUrl,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              color: AppColors.softGrey,
              child: const Center(
                child: Icon(Icons.image_not_supported_outlined,
                    color: AppColors.textGrey, size: 60),
              ),
            ),
          ),

          // Gradient gelap di bawah foto
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.75),
                  ],
                  stops: const [0.4, 1.0],
                ),
              ),
            ),
          ),

          // Badge Status (kiri bawah foto)
          Positioned(
            bottom: 70,
            left: 20,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: item.statusColor,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                item.status,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ),

          // Nama Barang (bawah foto)
          Positioned(
            bottom: 16,
            left: 20,
            right: 20,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.nama.toUpperCase(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    height: 1.1,
                    shadows: [
                      Shadow(
                          color: Colors.black54,
                          blurRadius: 8,
                          offset: Offset(0, 2))
                    ],
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(Icons.location_on_outlined,
                        color: AppColors.primaryYellow, size: 14),
                    const SizedBox(width: 4),
                    Text(
                      item.lokasi,
                      style: const TextStyle(
                        color: AppColors.primaryYellow,
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ========================
  // WIDGET: TOMBOL BACK & BOOKMARK
  // ========================
  Widget _buildTopButtons(BuildContext context) {
    return Positioned(
      top: 48,
      left: 16,
      right: 16,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Tombol Back
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 36,
              height: 36,
              decoration: const BoxDecoration(
                color: AppColors.primaryBlue,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.chevron_left,
                  color: AppColors.primaryYellow, size: 24),
            ),
          ),

          // Tombol Bookmark
          Container(
            width: 36,
            height: 36,
            decoration: const BoxDecoration(
              color: Colors.red,
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.bookmark_border,
                color: Colors.white, size: 20),
          ),
        ],
      ),
    );
  }

  // ========================
  // WIDGET: BANNER IMBALAN
  // ========================
  Widget _buildImbalanBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.primaryYellow,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Row(
        children: [
          const Icon(Icons.card_giftcard,
              color: AppColors.primaryBlue, size: 28),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Imbalan dari pemilik',
                style: TextStyle(
                  fontSize: 11,
                  color: AppColors.primaryBlue,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                item.imbalan!,
                style: const TextStyle(
                  fontSize: 18,
                  color: AppColors.primaryBlue,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ========================
  // WIDGET: DESKRIPSI LENGKAP
  // ========================
  Widget _buildDeskripsi() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Deskripsi Lengkap',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: AppColors.primaryBlue,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          item.deskripsi,
          style: const TextStyle(
            fontSize: 13,
            color: Colors.black54,
            height: 1.5,
          ),
        ),
      ],
    );
  }

  // ========================
  // WIDGET: CHIP KATEGORI & WAKTU
  // ========================
  Widget _buildInfoChips() {
    return Row(
      children: [
        _infoChip('Kategori', item.kategori),
        const SizedBox(width: 12),
        _infoChip('Waktu Lapor', item.waktuLapor),
      ],
    );
  }

  Widget _infoChip(String label, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          border: Border.all(
              color: AppColors.secondaryBlue.withOpacity(0.6), width: 1.5),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: const TextStyle(
                fontSize: 10,
                color: AppColors.textGrey,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              value,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.bold,
                color: AppColors.primaryBlue,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ========================
  // WIDGET: TOMBOL KLAIM
  // ========================
  Widget _buildKlaimButton(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryBlue,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30)),
        ),
        icon: const Icon(Icons.check_circle_outline,
            color: AppColors.primaryYellow, size: 20),
        label: const Text(
          'AJUKAN KLAIM',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontSize: 15,
            letterSpacing: 1,
          ),
        ),
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Klaim berhasil diajukan (Dummy)')),
          );
        },
      ),
    );
  }
}